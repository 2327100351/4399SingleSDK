package cn.m4399.single.demo;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;

import cn.m4399.single.api.GiftCodeValidateListener;
import cn.m4399.single.api.OperateConfig;
import cn.m4399.single.api.SingleOperateCenter;

import static android.content.res.Configuration.ORIENTATION_PORTRAIT;
import static cn.m4399.single.demo.PermissionHelper.PERMISSION_REQUEST_CODE;

public class MainActivity extends FragmentActivity {
    public static final String TAG = "4399Single";
    public static final String TOAST_PREFIX = "【DEMO】";

    RechargeController mRechargeController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.demo_main_activity);
        mRechargeController = new RechargeController(this);
        initSDK();
    }

    private int getGameOrientation() {
        // SDK界面支持的四种方向配置：
        // ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, // 0，横屏
        // ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, // 1，竖屏
        // ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, // 6，横屏180度旋转
        // ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT // 7，竖屏180度旋转*/
        //
        // 接入方应该直接设置和应用一致的方向即可，但SDK依赖的第三方页面，仍然要在AndroidManifest中设置
        int orientation = getResources().getConfiguration().orientation;
        return orientation == ORIENTATION_PORTRAIT ?
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT :
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSION_REQUEST_CODE) {
            initSDK();
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    private void initSDK() {
        if (PermissionHelper.hasPermission(this)) {
            //初始化SDK
            OperateConfig config = new OperateConfig()
                    .debuggable(false)  //发布游戏时，要设为false
                    .orientation(getGameOrientation()) //设置SDK界面方向，应与游戏设置一直
                    .supportExcess(true) // 设置“是否支持超出金额”默认值，也可以在每次充值的订单信息里设置
                    .gameKey(getString(R.string.demo_label_game_key))    //换成实际游戏的game key
                    .gameName(getString(R.string.demo_label_game_name));   //换成实际游戏的名字，原则上与游戏名字匹配
            SingleOperateCenter.init(this, config, mRechargeController.singleRechargeListener);
            //如无需激活码验证功能，删除此项初始化即可
//            GameActivation.activate(MainActivity.this,getString(R.string.demo_label_game_key), false);

            //显示SDK版本信息
            TextView versionText = findViewById(R.id.text_version);
            versionText.setText(getString(R.string.demo_fmt_version, SingleOperateCenter.getVersion()));
        } else {
            PermissionHelper.requestPermission(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        SingleOperateCenter.destroy();
    }

    /*
     * 测试自定义增量更新
     * <p>
     * 自定义增量更新允许开发者定制升级界面
     */
    public void onUpgradeBtnClicked(View view) {
        new UpgradeController().doUpgrade(this);
    }

    public void onRechargeBtnClicked(View view) {
        mRechargeController.doRecharge();
    }

    public void onCommodityBtnClicked(View view) {
        mRechargeController.showCommodities();
    }

    public void onGiftCheckBtnClicked(View view) {
        SingleOperateCenter.validateGiftCode(MainActivity.this, new GiftCodeValidateListener() {
            @Override
            public void onValidated(String code, String key) {
                // 接入方发放奖励，或进一步验证
            }
        });
    }
}
