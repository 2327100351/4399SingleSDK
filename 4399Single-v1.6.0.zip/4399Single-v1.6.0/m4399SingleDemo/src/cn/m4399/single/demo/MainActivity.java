package cn.m4399.single.demo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import cn.m4399.activation.api.GameActivation;
import cn.m4399.operate.OperateCenterConfig;
import cn.m4399.operate.SingleOperateCenter;
import cn.m4399.operate.SingleOperateCenter.SingleRechargeListener;
import cn.m4399.operate.UpgradeInfo;
import cn.m4399.operate.model.callback.Callbacks.OnCheckFinishedListener;
import cn.m4399.operate.model.callback.Callbacks.OnDownloadListener;
import cn.m4399.recharge.RechargeOrder;
import pub.devrel.easypermissions.EasyPermissions;

public class MainActivity extends Activity implements EasyPermissions.RationaleCallbacks {
    public static final String TAG = "4399SDK-GameActivity";
    public static final String TOAST_PREFIX = "【DEMO】";

    // SDK界面支持的四种方向配置
    public static final Integer[] mOrientations = new Integer[]{
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, // 0，横屏
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, // 1，竖屏
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, // 6，横屏180度旋转
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT // 7，竖屏180度旋转
    };
    private static final int CODE_REQUEST_PERMISSIONS = 124;

    private static final String[] RequestPermissions = new String[]{
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE,
    };

    SingleOperateCenter mOpeCenter;
    SharedPreferences mSp;

    private ArrayList<String> mSKUList; //临时存储购买成功的物品，当activity在活动时显示出来

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mSp = getSharedPreferences("sdk_sp", MODE_PRIVATE);
        // 设置Demo Activity的方向
        setDemoOrientation();
        setContentView(R.layout.main);

        initOrientationSpinner();
        if (EasyPermissions.hasPermissions(this, RequestPermissions)) {
            //初始化SDK
            initSDK();
        } else {
            EasyPermissions.requestPermissions(this, getString(R.string.demo_tip_permission_tip),
                    CODE_REQUEST_PERMISSIONS, RequestPermissions);
        }

        //显示SDK版本信息
        showSDKVersion();

        //初始化物品列表
        initSKUList();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (EasyPermissions.hasPermissions(this, RequestPermissions)) {
            //初始化SDK
            initSDK();
        } else {
            EasyPermissions.requestPermissions(this, getString(R.string.demo_tip_permission_tip),
                    CODE_REQUEST_PERMISSIONS, RequestPermissions);
        }
    }

    @Override
    public void onRationaleAccepted(int requestCode) {

    }

    @Override
    public void onRationaleDenied(int requestCode) {
        finish();
    }

    private void initSKUList() {
        mSKUList = new ArrayList<>();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mOpeCenter.destroy();
        mOpeCenter = null;
    }

    private void showSDKVersion() {
        TextView versionText = findViewById(R.id.text_version);
        versionText.setText(String.format(getString(R.string.demo_fmt_version), SingleOperateCenter.getVersion()));
    }

    private void initSDK() {
        mOpeCenter = SingleOperateCenter.getInstance();
        new OperateCenterConfig.Builder(this)
                .setDebugEnabled(false)  //发布游戏时，要设为false
                .setOrientation(getOrientation()) //设置SDK界面方向，应与游戏设置一直
                .setSupportExcess(true) //设置是否支持超出金额充值
                .setGameKey(getString(R.string.demo_label_game_key))    //换成实际游戏的game key
                .setGameName(getString(R.string.demo_label_game_name))    //换成实际游戏的名字，原则上与游戏名字匹配
                .build();

        SingleRechargeListener singleRechargeListener = new SingleRechargeListener() {

            /*
             * 充值过程结束时SDK回调此方法
             *
             * 充值过程结束并不代表订单生命周期全部完成，SDK还需要查询订单状态，游戏
             * 要根据订单状态决定是否发放物品等
             *
             * @param msg 表示充值结果的友好的文本说明
             *
             */
            @Override
            public void onRechargeFinished(boolean success, String msg) {
                Log.d(TAG, "Pay: [" + success + ", " + msg + "]");
                showInToast(msg);
            }

            /*
             * 充值过程成功完成后，SDK会查询订单状态，根据订单状态状态正常则通知游戏发放物品
             *
             * @param shouldDeliver
             *  是否要发放物品
             * @param o
             *  封装了最后提交的订单信息的对象，主要包含以下成员，各成员都有getter方法
             *  payChannel：   充值渠道
             *  orderId：      	充值订单号
             *  je：			充值金额
             *  goods：        	购买的物品
             *
             * @return
             *  物品发放过程是否成功
             */

            @Override
            public boolean notifyDeliverGoods(boolean shouldDeliver, RechargeOrder o) {
                if (shouldDeliver) {
                    Log.d(TAG, String.format(getString(R.string.demo_fmt_distribution_of_goods), o.toString()));
                    showInToast(String.format(getString(R.string.demo_fmt_distribution_of_goods), o.toString()));
                    mSKUList.add(String.format(getString(R.string.demo_fmt_recharge_detail), o.getJe(), o.getGoods()));

                    return true;
                } else {
                    Log.d(TAG, "notifyDeliverGoods error");
                    return false;
                }
            }
        };
        mOpeCenter.init(MainActivity.this, singleRechargeListener);

        //如无需激活码验证功能，删除此项初始化即可
        GameActivation.activate(MainActivity.this, OperateCenterConfig.getConfig().getGameKey(), false);
    }

    /*
     * 测试SDK界面的方向设置
     *
     * 为了在Demo中测试横竖屏，提供Spinner控件设置方向配置，并保持着SharedPreference中
     * 实际接入直接设置OperateCenterConfig
     * .Builder(this)。setOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
     *
     * 注意：横竖屏设置都需要重启Demo才能生效; 测试旋转屏幕时要开启“自动旋转屏幕”
     */
    private void setDemoOrientation() {
        int ori = getOrientation();
        setRequestedOrientation(ori);
    }

    private void showInToast(String msg) {
        Toast.makeText(MainActivity.this, TOAST_PREFIX + msg, Toast.LENGTH_SHORT).show();
    }

    public void initOrientationSpinner() {
        Spinner spinner = findViewById(R.id.m4399_demo_ori_spinner);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{
                getString(R.string.demo_label_landscape), getString(R.string.demo_label_portrait),
                getString(R.string.demo_label_landscape_rotating), getString(R.string.demo_label_portrait_rotating)
        });
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                Log.d(TAG, "Set orientation as " + mOrientations[pos]);
                saveOrientation(mOrientations[pos]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        // 这里设置默认方向为横屏，SDK内部的默认方向也是
        spinner.setSelection(getOriIndex());
    }

    private int getOriIndex() {
        int index = 0;
        int orientation = getOrientation();
        for (int i = 0; i < mOrientations.length; i++) {
            if (orientation == mOrientations[i])
                index = i;
        }
        return index;
    }

    private int getOrientation() {
        return mSp.getInt("orientation", ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }

    private void saveOrientation(int orientation) {
        for (Integer mOrientation : mOrientations) {
            if (mOrientation == orientation)
                mSp.edit().putInt("orientation", mOrientation).apply();
        }
    }

    /**
     * 测试自定义增量更新
     * <p>
     * 自定义增量更新允许开发者定制升级界面
     */
    public void onUpdateButtonClicked(View view) {
        Log.d(TAG, "Update Button Clicked...");

        mOpeCenter.doCheck(MainActivity.this, new OnCheckFinishedListener() {
            @Override
            public void onCheckResponse(UpgradeInfo upgradeInfo) {
                Log.d(TAG, "onCheckResponse, " + upgradeInfo);
                showCheckResult(upgradeInfo);
            }
        });
    }

    //显示更新结果
    private void showCheckResult(UpgradeInfo info) {
        int code = info.getResultCode();
        final boolean haveLocalSrc = info.haveLocalSrc();

        Builder builder = new Builder(MainActivity.this);
        StringBuilder msgBuilder = new StringBuilder();

        if (code == UpgradeInfo.APK_CHECK_NO_UPDATE) {
            msgBuilder.append(getString(R.string.demo_warning_last_version));
            builder.setNegativeButton(getString(R.string.demo_message_i_see), new OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
        } else if (code == UpgradeInfo.APK_CHECK_NEED_UPDATE) {
            msgBuilder.append(getString(R.string.demo_label_new_version_code))
                    .append(info.getVersionName() + "-" + info.getVersionCode())
                    .append(getString(R.string.demo_label_time))
                    .append(info.getUpgradeTime())
                    .append(getString(R.string.demo_label_is_mandatory_update))
                    .append(info.isCompel())
                    .append(getString(R.string.demo_label_update_size))
                    .append(info.getUpgradeSize() + "/" + info.getNewApkSize())
                    .append(getString(R.string.demo_label_update_content)).append(info.getUpgradeMsg());
            String action = haveLocalSrc ? getString(R.string.demo_title_install_package) : getString(R.string.demo_action_update_start);

            builder.setPositiveButton(action, new OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (haveLocalSrc)
                        mOpeCenter.doInstall(MainActivity.this);
                    else
                        doDownload();
                }

            }).setNegativeButton(getString(R.string.demo_action_update_cancel), new OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }

            });
        } else {
            msgBuilder.append(getString(R.string.demo_tip_check_update_error));
            msgBuilder.append("\ncode: ").append(code).append(getString(R.string.demo_error_check_update_error_info)).append(info.getResultMsg());
            builder.setNegativeButton(getString(R.string.demo_message_i_see), new OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
        }

        builder.setTitle(getString(R.string.demo_title_update_custom)).setMessage(msgBuilder);
        builder.create().show();
    }

    private void doDownload() {
        final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
        dialog.setMessage(getString(R.string.demo_label_prepare_download));
        dialog.show();

        mOpeCenter.doDownload(MainActivity.this, new OnDownloadListener() {

            @Override
            public void onDownloadSuccess() {
                Log.d(TAG, "onUpdateSuccess");
                dialog.setMessage(getString(R.string.demo_tip_download_success));
                doInstall();

                dialog.dismiss();
            }

            @Override
            public void onDownloadFail(int resultCode, String eMsg) {
                Log.d(TAG, "onUpdateFail");
                dialog.setMessage(getString(R.string.demo_tip_download_fail));
                dialog.dismiss();
            }

            @Override
            public void onDownloadStart() {
                Log.d(TAG, "onUpdateStart");
                dialog.setMessage(getString(R.string.demo_action_update_start));
            }

            @Override
            public void onDownloadProgress(long progress, long max) {
                long percentage = progress * 100 / max;
                dialog.setMessage(String.format(getString(R.string.demo_fmt_update_progress), percentage + "%"));
            }
        });
    }

    private void doInstall() {
        Builder builder = new Builder(MainActivity.this);
        builder.setTitle(getString(R.string.demo_title_install_package)).setMessage(getString(R.string.demo_message_is_install_right_now)
        ).setPositiveButton(getString(R.string.demo_action_install_right_now), new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mOpeCenter.doInstall(MainActivity.this);
            }
        }).setNegativeButton(getString(R.string.demo_action_temporary_not), new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.create().show();
    }

    /**************** 结束自定义更新测试 **********************/

    @SuppressLint("InflateParams")
    public void onRechargeButtonClicked(View view) {
        Log.d(TAG, "Pay Button Clicked...");

        final ScrollView sv = (ScrollView) LayoutInflater.from(this).inflate(R.layout.params_scrollview, null);
        Builder builder = new Builder(MainActivity.this);

        builder.setTitle(R.string.demo_action_start_pay).setView(sv).setNegativeButton("Cancel", new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }).setPositiveButton("OK", new OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                TextView jeTV = sv.findViewById(R.id.je);
                String je = jeTV.getText().toString();

                TextView subjectTV = sv.findViewById(R.id.subject);
                String productName = subjectTV.getText().toString();

                //是否支持超出金额，这里是一个独立的接口，只要在充值之前调用都有作用
                CheckBox chCB = sv.findViewById(R.id.changable);
                boolean supportExcess = chCB.isChecked();
                mOpeCenter.setSupportExcess(supportExcess);
                //是否传入商品名，这会影响商品在充值界面的显示
                CheckBox hsCB = sv.findViewById(R.id.have_subject);
                boolean hasSubject = hsCB.isChecked();
                if (!hasSubject) {
                    productName = null;
                }

                Log.d(TAG, "[" + je + ", " + productName + ", " + supportExcess + "]");

                //mOpeCenter.recharge(MainActivity.this, je, productName);
                mOpeCenter.recharge(MainActivity.this, je, productName, getString(R.string.demo_label_test_extra));
                dialog.dismiss();
            }
        }).create().show();
    }

    @SuppressLint("InflateParams")
    public void onPurchaseButtonClicked(View view) {
        LinearLayout container = (LinearLayout) LayoutInflater.from(this).inflate(R.layout.product_list, null);
        ListView skuListView = container.findViewById(R.id.product_list);
        skuListView.setAdapter(new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, mSKUList));

        Builder builder = new Builder(MainActivity.this)
                .setTitle(getString(R.string.demo_title_buy_goods))
                .setView(container)
                .setPositiveButton(getString(R.string.demo_action_sure), new OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        builder.create().show();
    }

    public void onCheckGiftClicked(View view) {
        mOpeCenter.validateGiftCode(MainActivity.this, new SingleOperateCenter.OnGiftCodeValidatedListener() {
            @Override
            public void onValidated(String code, String key) {
            }
        });
    }
}
